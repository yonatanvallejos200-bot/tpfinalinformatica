// USHUAIA · FIN DEL MUNDO | Interactividad con JavaScript

// Año automático en el pie de página.
document.getElementById("year").textContent = new Date().getFullYear();

// Contador local: cuenta las visitas desde este navegador/dispositivo.
const visitKey = "ushuaiaSiteVisits";
let visits = Number(localStorage.getItem(visitKey) || 0);
visits += 1;
localStorage.setItem(visitKey, visits);
document.getElementById("visitCount").textContent = visits;

// Calculadora: días x presupuesto diario.
const calculateBtn = document.getElementById("calculateBtn");
calculateBtn.addEventListener("click", () => {
  const days = Number(document.getElementById("days").value);
  const daily = Number(document.getElementById("daily").value);
  const result = document.getElementById("calcResult");

  if (!Number.isInteger(days) || days < 1 || days > 30 || !Number.isFinite(daily) || daily < 0) {
    result.textContent = "Ingresá entre 1 y 30 días y un presupuesto válido.";
    return;
  }

  const total = days * daily;
  result.textContent = `Total estimado: ${total.toLocaleString("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0
  })}`;
});

// Formulario de contacto demostrativo: valida los datos y muestra un mensaje.
const contactForm = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");

contactForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!contactForm.checkValidity()) {
    contactForm.classList.add("was-validated");
    formMessage.textContent = "Revisá los campos: todos son obligatorios y el correo debe ser válido.";
    formMessage.className = "form-message error";
    return;
  }

  const visitorName = document.getElementById("name").value.trim();
  formMessage.textContent = `¡Gracias, ${visitorName}! Tu mensaje de prueba quedó registrado en esta página.`;
  formMessage.className = "form-message success";
  contactForm.reset();
  contactForm.classList.remove("was-validated");
});

// Cierra el menú móvil después de elegir una sección.
document.querySelectorAll(".navbar-nav .nav-link").forEach((link) => {
  link.addEventListener("click", () => {
    const menu = document.getElementById("menu");
    if (menu.classList.contains("show")) {
      bootstrap.Collapse.getOrCreateInstance(menu).hide();
    }
  });
});
